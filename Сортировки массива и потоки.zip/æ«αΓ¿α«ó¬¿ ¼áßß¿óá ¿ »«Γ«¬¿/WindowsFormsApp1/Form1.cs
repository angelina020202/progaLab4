﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // количество столбцов и строк в таблице
            GLOBAL.cols = 0;
            GLOBAL.rows = 0;
        }

        // объявление глобальных переменных
        static Thread[] threads;// массив потоков
        // сколько потоков еще не зашло из макс. колва в секцию, максимальное колво потоков
        // общее колво потоков, работающих одновременно = 4
        static Semaphore semaphore = new Semaphore(4, 4);



        // ======================== МЕТОДЫ ========================================

        // создание шапки таблицы DataGridView
        public void setTableHead(DataGridView dGrid, string[] fields, int[] nWidth, int countLastHidenItems = 0)
        {// создание шапки таблицы DataGridView
            // countLastHidenItems - колво последних скрытых столбцов
            dGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;//выделение всей строки кликом
            dGrid.Cursor = System.Windows.Forms.Cursors.Hand;//смена курсора
            int nCount = fields.Length;//колво полей таблицы
            dGrid.Columns.Clear();
            DataGridViewTextBoxColumn[] column = new DataGridViewTextBoxColumn[nCount];
            for (int i = 0; i < nCount; i++)
            {
                column[i] = new DataGridViewTextBoxColumn(); // выделяем память для объекта
                column[i].HeaderText = fields[i];
                column[i].Name = "Header" + i;
                column[i].Width = nWidth[i];
                // скрыть последнюю колонку
                if (nCount - 1 - i < countLastHidenItems) column[i].Visible = false;
            }
            dGrid.Columns.AddRange(column); // добавление столбцов
        }

        
        // СОРТИРОВКИ

        // сортировка пузырьком
        static void sortingBubble(object obj)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            // обработка данного кода одним потоком, в одно время
            // блокирует доступ других потоков к участку кода
            semaphore.WaitOne();

            // обход каждого элемента массива для сортировки
            int size = GLOBAL.rows * GLOBAL.cols;
            for (int i = 1; i<size; i++)
	        {
                for (int j = size - 1; j >= i; j--)
		        {
			        // если значение в одном элементе массива больше чем в другом, 
			        // меняем элементы местами
			        if (GLOBAL.data[j - 1] > GLOBAL.data[j])
			        {// смена элементов местами
				        int t = GLOBAL.data[j - 1];
                        GLOBAL.data[j - 1] = GLOBAL.data[j];
                        GLOBAL.data[j] = t;
			        }
                }
                // вывод результата сортировки
                Program.form1.displayArray();
                Thread.Sleep(10);// пауза
            }

            // разблокировка семафором участка кода для других потоков
            semaphore.Release();
            
            // запись времени работы сортировки
            sw.Stop();            // запись времени сортировки в м/сек
            GLOBAL.sortingTime[0] = sw.ElapsedMilliseconds;

            // остановка работы потока
            threads[0] = null;
        }

        // сортировка вставками
        void sortInsertion(object obj)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            // обработка данного кода одним потоком, в одно время
            // блокирует доступ других потоков к участку кода
            semaphore.WaitOne();

            // обход каждого элемента массива для сортировки
            int size = GLOBAL.rows * GLOBAL.cols;


            int temp, // временная переменная для хранения значения элемента сортируемого массива
                item; // индекс предыдущего элемента
            for (int counter = 1; counter < size; counter++)
            {
                temp = GLOBAL.data[counter]; // инициализируем временную переменную текущим значением элемента массива
                item = counter - 1; // запоминаем индекс предыдущего элемента массива
                while (item >= 0 && GLOBAL.data[item] > temp) // пока индекс не равен 0 и предыдущий элемент массива больше текущего
                {
                    // перестановка элементов массива
                    GLOBAL.data[item + 1] = GLOBAL.data[item];
                    GLOBAL.data[item] = temp;
                    item--;
                }
                // вывод результата сортировки
                Program.form1.displayArray();
                Thread.Sleep(10);// пауза
            }

            // разблокировка семафором участка кода для других потоков
            semaphore.Release();

            // запись времени работы сортировки
            sw.Stop();
            // запись времени сортировки в м/сек
            GLOBAL.sortingTime[1] = sw.ElapsedMilliseconds;
            threads[1] = null;
        }

        // шейкерная сортировка
        void sortShaker(object obj)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            // обработка данного кода одним потоком, в одно время
            // блокирует доступ других потоков к участку кода
            semaphore.WaitOne();

            // обход каждого элемента массива для сортировки
            int size = GLOBAL.rows * GLOBAL.cols;
            int leftMark = 1;
            int rightMark = size - 1;
            while (leftMark <= rightMark)
            {
                for (int i = rightMark; i >= leftMark; i--)
                    if (GLOBAL.data[i - 1] > GLOBAL.data[i]) {
                        int buff = GLOBAL.data[i];
                        GLOBAL.data[i] = GLOBAL.data[i - 1];
                        GLOBAL.data[i - 1] = buff;
                    }
                leftMark++;


                for (int i = leftMark; i <= rightMark; i++)
                    if (GLOBAL.data[i - 1] > GLOBAL.data[i]) {
                        int buff = GLOBAL.data[i];
                        GLOBAL.data[i] = GLOBAL.data[i - 1];
                        GLOBAL.data[i - 1] = buff;
                    } 
                rightMark--;

                // вывод результата сортировки
                Program.form1.displayArray();
                Thread.Sleep(10);// пауза
            }

            // разблокировка семафором участка кода для других потоков
            semaphore.Release();

            // запись времени работы сортировки
            sw.Stop();
            // запись времени сортировки в м/сек
            GLOBAL.sortingTime[2] = sw.ElapsedMilliseconds;

            threads[2] = null;
        }

        // обертка для метода быстрой сортировки
        void wrapQuickSorting(object obj)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            // обработка данного кода одним потоком, в одно время
            // блокирует доступ других потоков к участку кода
            semaphore.WaitOne();

            // вызов рекурсивной функции сортировки
            int size = GLOBAL.rows * GLOBAL.cols;
            quickSort(0, size - 1);

            // разблокировка семафором участка кода для других потоков
            semaphore.Release();

            // запись времени работы сортировки
            sw.Stop();
            // запись времени сортировки в м/сек
            GLOBAL.sortingTime[3] = sw.ElapsedMilliseconds;

            threads[3] = null;
        }

        // сортировка массива методом quickSort (быстрая сортировка / метод Хоара)
        void quickSort(int low, int high)
        {
            //low = 0; hight = size-1;
            int i = low;
            int j = high;
            int pivot = GLOBAL.data[(i + j) / 2];
            int temp;

            while (i <= j)
            {
                while (GLOBAL.data[i] < pivot) i++;
                while (GLOBAL.data[j] > pivot) j--;

                if (i <= j)
                {
                    temp = GLOBAL.data[i];
                    GLOBAL.data[i] = GLOBAL.data[j];
                    GLOBAL.data[j] = temp;
                    i++;
                    j--;
                }
            }
            
            // вывод результата сортировки
            Program.form1.displayArray();
            Thread.Sleep(10);// пауза

            if (j > low) quickSort(low, j);
            if (i < high) quickSort(i, high);
        }


        // вывод элементов массива в таблицу
        void displayArray()
        {
            int index = 0;
            // обход каждого элемента массива для сортировки
            int size = GLOBAL.rows * GLOBAL.cols;
            for (int i = 0; i < GLOBAL.rows; i++)
            {
                for (int j = 0; j < GLOBAL.cols; j++)
                {
                    // добавление строки в таблицу
                    dataGridView1[j, i].Value = GLOBAL.data[index++].ToString();
                }
            }
        }



        // кнопка рассчитать
        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            // проверка, что установлено колво элементов
            if (GLOBAL.cols == 0 || GLOBAL.rows == 0) {
                MessageBox.Show("Необходимо установить колво элементов для сортировки!", "Внимание!",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            // проверка, что выбран хотябы один вид сортировки
            if (GLOBAL.sorting[0] == 0 && GLOBAL.sorting[1] == 0 && GLOBAL.sorting[2] == 0 && GLOBAL.sorting[3] == 0)
            {
                MessageBox.Show("Необходимо выбрать хотябы один тип сортировки!", "Внимание!",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }


            // перепишем значения из таблицы в массив, т.к. значения могли изменяться в ячейках таблицы
            // запись случайного значения в элемент массива
            // струки и столбцы для обращения к нужной ячейки таблицы
            int row = 0;// строка
            int col = 0;// столбец
            for (int i = 0; i < GLOBAL.cols * GLOBAL.rows; i++) {
                // контролируем значения в колонках и строках, для перемещения по таблице
                if (col > GLOBAL.cols-1) {
                    col = 0; 
                    row++;
                }
                // получение значения ячейка DataGridView
                GLOBAL.data[i] = Convert.ToInt32(dataGridView1[col++, row].Value);
            }

            // запуск отмеченных сортировок
            // создание массива потоков для четырех сортировок
            threads = new Thread[4];


            for (int i = 0; i < 4; i++) {
                if (GLOBAL.sorting[i] > 0) {
                    // инициализация потоков
                    if(i == 0) threads[0] = new Thread(new ParameterizedThreadStart(sortingBubble));
                    if(i == 1) threads[1] = new Thread(new ParameterizedThreadStart(sortInsertion));
                    if(i == 2) threads[2] = new Thread(new ParameterizedThreadStart(sortShaker));
                    if(i == 3) threads[3] = new Thread(new ParameterizedThreadStart(wrapQuickSorting));
                    
                    threads[i].Start();// запуск потока
                } 
            }

            
            // ожидание завершения работы всех потоков

            timer1.Start();
        }

        // ожидание завершения работы всех потоков
        static void waitingCloseAllThreads()
        {
            // ожидание завершения работы всех потоков
            int countOpenThreads = 0;
            int size = 4;// колво открытых потоков
            // пока есть хоть один не завершенный поток, осуществляем проверку в цикле
            do
            {
                //Thread.Sleep(5);// запуск цикла, каждые 0.5 сек
                countOpenThreads = size;
                for (int i = 0; i < size; i++)
                {
                    if (threads[i] == null) countOpenThreads--;
                }
            } while (countOpenThreads > 0);
        }

        // выход из программы
        private void toolStripMenuItem4_Click(object sender, EventArgs e) { Application.Exit(); }

        // открыть окно для установки количества элементов
        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.ShowDialog();
            if (GLOBAL.rows == 0 || GLOBAL.cols == 0) {
                dataGridView1.Rows.Clear();
                dataGridView1.Columns.Clear();
                return;
            }

            // создание шапки таблицы DataGridView в установленном размере
            // названия полей шапки (1,2,3)
            string[] fields = new string[GLOBAL.cols];
            // ширина столбцов таблицы
            int[] nWidth = new int[GLOBAL.rows * GLOBAL.cols];

            // ширина колонок
            for (int i = 0; i < GLOBAL.cols; i++) {
                fields[i] = (i + 1).ToString();
                nWidth[i] = 30;
            }
            // создание шапки таблицы
            setTableHead(dataGridView1, fields, nWidth);

            //добавление строки в таблицу
            Random rand = new Random();
            int randValue = 0;// случайное значение
            for (int i = 0; i < GLOBAL.rows; i++) {
                string[] line = new string[GLOBAL.cols];
                for (int j = 0; j < GLOBAL.cols; j++) {
                    // генерация псевдослучайного значения в заданном диапазоне
                    randValue = rand.Next(100, 999);
                    // запись случайного значения в таблицу
                    line[j] = randValue.ToString();
                }
                dataGridView1.Rows.Add(line);
            }

            toolStripStatusLabel1.Text = "Колво элементов: " + (GLOBAL.rows * GLOBAL.cols).ToString();
        }

        // открыть форму сортировок
        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3();
            f.ShowDialog();
        }

        // очистить таблицу
        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();
            GLOBAL.cols = 0;
            GLOBAL.rows = 0;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // ожидание завершения работы всех потоков
            int countOpenThreads = 0;
            int size = 4;// колво открытых потоков
            // пока есть хоть один не завершенный поток, осуществляем проверку в цикле
            do
            {
                //Thread.Sleep(5);// запуск цикла, каждые 0.5 сек
                countOpenThreads = size;
                for (int i = 0; i < size; i++)
                {
                    if (threads[i] == null) countOpenThreads--;
                }
            } while (countOpenThreads > 0);
            if (countOpenThreads == 0) {
                // вывод результатов скорости сортировки
                string result = "";
                for (int i = 0; i < 4; i++)
                {
                    if (GLOBAL.sortingTime[i] > 0)
                    {
                        if (i == 0) result += "Пузырьком: " + GLOBAL.sortingTime[0] + " м/cек\n";
                        if (i == 1) result += "Вставками: " + GLOBAL.sortingTime[1] + " м/cек\n";
                        if (i == 2) result += "Шейкерная: " + GLOBAL.sortingTime[2] + " м/cек\n";
                        if (i == 3) result += "Быстрая: " + GLOBAL.sortingTime[3] + " м/cек\n";
                    }
                }
                timer1.Enabled = false;
                MessageBox.Show("Результат сортировкки: \n" + result);
            }
        }
    }
}
