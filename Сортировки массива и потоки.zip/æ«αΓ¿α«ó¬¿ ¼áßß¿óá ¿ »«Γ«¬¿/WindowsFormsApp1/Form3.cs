﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // сброс сортировок
            GLOBAL.sorting[0] = GLOBAL.sorting[1] = GLOBAL.sorting[2] = GLOBAL.sorting[3] = 0;
            // сброс времени сортировок
            GLOBAL.sortingTime[0] = GLOBAL.sortingTime[1] = GLOBAL.sortingTime[2] = GLOBAL.sortingTime[3] = 0;
            // записываем значения в массив типов сортировки из установленных флажков
            if (checkBox1.Checked) GLOBAL.sorting[0] = 1;
            if (checkBox2.Checked) GLOBAL.sorting[1] = 1;
            if (checkBox3.Checked) GLOBAL.sorting[2] = 1;
            if (checkBox4.Checked) GLOBAL.sorting[3] = 1;

            if(GLOBAL.sorting[0] == 0 && GLOBAL.sorting[1] == 0 && GLOBAL.sorting[2] == 0 && GLOBAL.sorting[3] == 0)
            {
                MessageBox.Show("Необходимо выбрать хотябы один тип сортировки!", "Внимание!",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            this.Hide();
        }

        // загрузка формы
        private void Form3_Load(object sender, EventArgs e)
        {
            // установить флажки на те элементы, которые уже были выбраны
            if (GLOBAL.sorting[0] > 0) checkBox1.Checked = true;
            if (GLOBAL.sorting[1] > 0) checkBox2.Checked = true;
            if (GLOBAL.sorting[2] > 0) checkBox3.Checked = true;
            if (GLOBAL.sorting[3] > 0) checkBox4.Checked = true;
        }
    }
}
