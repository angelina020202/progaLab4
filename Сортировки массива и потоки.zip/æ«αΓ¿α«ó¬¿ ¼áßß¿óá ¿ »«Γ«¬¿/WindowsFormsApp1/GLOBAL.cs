﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    static class GLOBAL
    {
        // количество элементов для сортировки
        public static int rows, cols;
        // виды допустимых сортировок
        public static int[] sorting = new int[4];
        // время в м/сек. затраченное на сортировку
        public static double[] sortingTime = new double[4];
        // массив данных
        public static int[] data;
    }
}
