﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        // проерка явлется ли строка числом
        bool isNumber(string s)
        {
            int i = 0;
            int len = s.Length;
            if (len == 0) return false;
            while (i < len)//цикл выполняется для каждого элемента строки s
            {//если значение с плавающей запятой
                if (s[i] < '0' || s[i] > '9') return false;
                i++;
            }
            return true;
        }

        bool btnClicked = false;// определяет, что кнопка "Установить" была нажата
        private void button1_Click(object sender, EventArgs e)
        {
            // проверки корректности ввода данных
            if (textBox1.Text == "" || textBox2.Text == "") {
                MessageBox.Show("Необходимо указать колво элементов!", "Внимание!", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!isNumber(textBox1.Text) || !isNumber(textBox2.Text))
            {
                MessageBox.Show("Необходимо ввести число!", "Внимание!",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // получение количества введенных строк и столбцов
            int rows = Convert.ToInt32(textBox1.Text);
            int cols = Convert.ToInt32(textBox2.Text);

            if ((rows < 1 || rows > 600) || (cols < 1 || cols > 600)) {
                MessageBox.Show("Допустимый диапазон от 1 до 600!", "Внимание!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // перепишем значения из локальных переменных в глобальные
            GLOBAL.rows = rows;
            GLOBAL.cols = cols;
            // инициализация массива
            GLOBAL.data = new int[rows * cols];
            btnClicked = true;
            this.Hide();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            // сброс значения при закрытии
            if (!btnClicked) {
                GLOBAL.cols = 0;
                GLOBAL.rows = 0;
                GLOBAL.data = null;
            }
        }
    }
}
